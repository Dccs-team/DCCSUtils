"""
DCCSUtils - Request Utility Library

Developer: Md Saimun
Team: DCCS
"""

from .dccsutils import DCCSUtils

__version__ = "1.0.0"
